function r = coin_flip(N)
  r = randi([0 1], 1, N);
endfunction
